import React, { useState } from 'react';
import { StepIndicator } from './components/StepIndicator';
import { Introduction } from './components/FormSteps/Introduction';
import { BasicInfo } from './components/FormSteps/BasicInfo';
import { SocialMediaDetails } from './components/FormSteps/SocialMediaDetails';
import { PaymentInfo } from './components/FormSteps/PaymentInfo';
import { Verification } from './components/FormSteps/Verification';
import { Confirmation } from './components/FormSteps/Confirmation';
import { ArrowLeft, ArrowRight } from 'lucide-react';

function App() {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    // Basic Info
    fullName: '',
    email: '',
    country: '',
    
    // Social Media Details
    pageName: '',
    pageUrl: '',
    followers: '',
    category: '',
    
    // Payment Info
    paymentMethod: '',
    
    // Verification
    verificationMethod: '',
    verificationFile: undefined as File | undefined,
    verificationText: '',
  });

  const steps = [
    'Introduction',
    'Basic Info',
    'Social Media',
    'Payment',
    'Verification',
    'Confirmation'
  ];

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleVerificationChange = (data: Partial<typeof formData>) => {
    setFormData((prev) => ({ ...prev, ...data }));
  };

  const handleNext = () => {
    setCurrentStep((prev) => Math.min(prev + 1, steps.length - 1));
  };

  const handleBack = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 0));
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return <Introduction />;
      case 1:
        return <BasicInfo formData={formData} onChange={handleInputChange} />;
      case 2:
        return <SocialMediaDetails formData={formData} onChange={handleInputChange} />;
      case 3:
        return <PaymentInfo formData={formData} onChange={handleInputChange} />;
      case 4:
        return <Verification formData={formData} onChange={handleVerificationChange} />;
      case 5:
        return <Confirmation />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="px-4 py-5 sm:p-6">
            <StepIndicator currentStep={currentStep} steps={steps} />
            
            <div className="mt-8">
              {renderStep()}
            </div>

            <div className="mt-8 flex justify-between">
              {currentStep > 0 && currentStep < steps.length - 1 && (
                <button
                  type="button"
                  onClick={handleBack}
                  className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back
                </button>
              )}
              
              {currentStep < steps.length - 1 && (
                <button
                  type="button"
                  onClick={handleNext}
                  className="ml-auto inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  {currentStep === 0 ? 'Get Started' : 'Next'}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;