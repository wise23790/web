import React, { useState } from 'react';
import { Upload, CheckCircle, Mail } from 'lucide-react';

interface VerificationProps {
  formData: {
    verificationMethod: string;
    verificationFile?: File;
    verificationText?: string;
  };
  onChange: (data: Partial<typeof formData>) => void;
}

export function Verification({ formData, onChange }: VerificationProps) {
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onChange({ verificationFile: e.dataTransfer.files[0] });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onChange({ verificationFile: e.target.files[0] });
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Page Ownership Verification</h2>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Select Verification Method
          </label>
          <div className="mt-4 grid gap-4">
            <label className="relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus:outline-none">
              <input
                type="radio"
                name="verificationMethod"
                value="screenshot"
                className="sr-only"
                checked={formData.verificationMethod === 'screenshot'}
                onChange={(e) => onChange({ verificationMethod: e.target.value })}
              />
              <div className="flex w-full items-center justify-between">
                <div className="flex items-center">
                  <div className="text-sm">
                    <p className="font-medium text-gray-900">Upload Screenshot</p>
                    <p className="text-gray-500">Upload a screenshot from Meta Business Suite showing you're the admin</p>
                  </div>
                </div>
                <Upload className="h-5 w-5 text-blue-600" />
              </div>
            </label>

            <label className="relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus:outline-none">
              <input
                type="radio"
                name="verificationMethod"
                value="text"
                className="sr-only"
                checked={formData.verificationMethod === 'text'}
                onChange={(e) => onChange({ verificationMethod: e.target.value })}
              />
              <div className="flex w-full items-center justify-between">
                <div className="flex items-center">
                  <div className="text-sm">
                    <p className="font-medium text-gray-900">Temporary Page Update</p>
                    <p className="text-gray-500">Add specific text to your page bio or create a verification post</p>
                  </div>
                </div>
                <CheckCircle className="h-5 w-5 text-blue-600" />
              </div>
            </label>

            <label className="relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus:outline-none">
              <input
                type="radio"
                name="verificationMethod"
                value="email"
                className="sr-only"
                checked={formData.verificationMethod === 'email'}
                onChange={(e) => onChange({ verificationMethod: e.target.value })}
              />
              <div className="flex w-full items-center justify-between">
                <div className="flex items-center">
                  <div className="text-sm">
                    <p className="font-medium text-gray-900">Email Verification</p>
                    <p className="text-gray-500">Verify using your page's public contact email</p>
                  </div>
                </div>
                <Mail className="h-5 w-5 text-blue-600" />
              </div>
            </label>
          </div>
        </div>

        {formData.verificationMethod === 'screenshot' && (
          <div
            className={`mt-4 flex justify-center rounded-lg border-2 border-dashed p-6 ${
              dragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <div className="text-center">
              {formData.verificationFile ? (
                <div className="space-y-2">
                  <CheckCircle className="mx-auto h-8 w-8 text-green-500" />
                  <p className="text-sm text-gray-600">{formData.verificationFile.name}</p>
                </div>
              ) : (
                <div className="space-y-2">
                  <Upload className="mx-auto h-8 w-8 text-gray-400" />
                  <div className="flex text-sm text-gray-600">
                    <label htmlFor="file-upload" className="relative cursor-pointer rounded-md font-medium text-blue-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-blue-500 focus-within:ring-offset-2 hover:text-blue-500">
                      <span>Upload a file</span>
                      <input
                        id="file-upload"
                        name="file-upload"
                        type="file"
                        className="sr-only"
                        onChange={handleFileChange}
                        accept="image/*"
                      />
                    </label>
                    <p className="pl-1">or drag and drop</p>
                  </div>
                  <p className="text-xs text-gray-500">PNG, JPG up to 10MB</p>
                </div>
              )}
            </div>
          </div>
        )}

        {formData.verificationMethod === 'text' && (
          <div className="mt-4 rounded-lg border border-gray-200 p-4">
            <p className="text-sm text-gray-600 mb-2">Add this text to your page:</p>
            <p className="font-medium text-gray-900 p-2 bg-gray-50 rounded">
              Partnering with AdNetwork 2024 🎯
            </p>
            <input
              type="text"
              className="mt-4 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              placeholder="Enter the URL where we can verify this text"
              value={formData.verificationText || ''}
              onChange={(e) => onChange({ verificationText: e.target.value })}
            />
          </div>
        )}
      </div>
    </div>
  );
}