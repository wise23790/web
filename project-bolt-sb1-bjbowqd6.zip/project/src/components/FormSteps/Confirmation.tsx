import React from 'react';
import { CheckCircle } from 'lucide-react';

export function Confirmation() {
  return (
    <div className="text-center space-y-6">
      <div className="flex justify-center">
        <CheckCircle className="h-16 w-16 text-green-500" />
      </div>
      
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-gray-900">Application Submitted!</h2>
        <p className="text-gray-600">
          Thank you for applying to our ad partnership program. Our team will review your
          application within the next 48 hours.
        </p>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg text-left">
        <h3 className="font-semibold text-blue-900 mb-2">What happens next?</h3>
        <ul className="space-y-2 text-sm text-blue-800">
          <li>• Our team will review your application</li>
          <li>• You'll receive an email with our decision</li>
          <li>• If approved, we'll send you onboarding instructions</li>
          <li>• You can start receiving ad opportunities immediately after onboarding</li>
        </ul>
      </div>

      <p className="text-sm text-gray-500">
        Questions? Contact our support team at support@adnetwork.com
      </p>
    </div>
  );
}