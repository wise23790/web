import React from 'react';
import { DollarSign, CreditCard, Calendar } from 'lucide-react';

interface PaymentInfoProps {
  formData: {
    paymentMethod: string;
  };
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
}

export function PaymentInfo({ formData, onChange }: PaymentInfoProps) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Payment Information</h2>

      <div className="bg-white rounded-lg space-y-6">
        <div className="space-y-4">
          <div>
            <label htmlFor="paymentMethod" className="block text-sm font-medium text-gray-700">
              Payment Method
            </label>
            <select
              id="paymentMethod"
              name="paymentMethod"
              value={formData.paymentMethod}
              onChange={onChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            >
              <option value="">Select a payment method</option>
              <option value="paypal">PayPal</option>
              <option value="bank">Bank Transfer</option>
              <option value="wise">Wise (TransferWise)</option>
            </select>
          </div>
        </div>

        <div className="bg-gray-50 p-6 rounded-lg space-y-4">
          <h3 className="text-lg font-semibold text-gray-900">How Payments Work</h3>
          
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <DollarSign className="w-5 h-5 text-blue-600 mt-1" />
              <div>
                <h4 className="font-medium text-gray-900">Earnings Structure</h4>
                <p className="text-sm text-gray-600">
                  Earn based on engagement rates and follower count. Rates start at $100 per successful campaign.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Calendar className="w-5 h-5 text-blue-600 mt-1" />
              <div>
                <h4 className="font-medium text-gray-900">Payment Schedule</h4>
                <p className="text-sm text-gray-600">
                  Payments are processed monthly, on the 1st of each month for the previous month's earnings.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <CreditCard className="w-5 h-5 text-blue-600 mt-1" />
              <div>
                <h4 className="font-medium text-gray-900">Minimum Payout</h4>
                <p className="text-sm text-gray-600">
                  Minimum payout threshold is $50. Earnings below this amount will roll over to the next payment period.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}