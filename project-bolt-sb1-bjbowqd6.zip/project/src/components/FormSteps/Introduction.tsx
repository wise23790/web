import React from 'react';
import { ArrowRight, DollarSign, CheckCircle, Clock } from 'lucide-react';

export function Introduction() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Welcome to Our Ad Partnership Program</h2>
      
      <div className="bg-white rounded-lg p-6 space-y-4">
        <p className="text-gray-600">
          Join our network of content creators and start monetizing your social media presence.
          Here's what you need to know about our partnership program:
        </p>

        <div className="grid gap-4 mt-6">
          <div className="flex items-start space-x-3">
            <DollarSign className="w-6 h-6 text-blue-600 mt-1" />
            <div>
              <h3 className="font-semibold text-gray-900">Competitive Earnings</h3>
              <p className="text-sm text-gray-600">
                Earn based on your engagement rates and follower count. Top performers can earn
                up to $5000 per month.
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <CheckCircle className="w-6 h-6 text-blue-600 mt-1" />
            <div>
              <h3 className="font-semibold text-gray-900">Simple Verification</h3>
              <p className="text-sm text-gray-600">
                Quick and easy verification process to confirm your page ownership and start
                earning.
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <Clock className="w-6 h-6 text-blue-600 mt-1" />
            <div>
              <h3 className="font-semibold text-gray-900">Fast Approval</h3>
              <p className="text-sm text-gray-600">
                Applications are reviewed within 48 hours. Get started quickly once approved.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-8 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-semibold text-blue-900">What you'll need:</h4>
          <ul className="mt-2 space-y-2 text-sm text-blue-800">
            <li>• Your basic contact information</li>
            <li>• Social media page details</li>
            <li>• Payment information for receiving earnings</li>
            <li>• Proof of page ownership</li>
          </ul>
        </div>
      </div>
    </div>
  );
}