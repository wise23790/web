import React from 'react';

interface SocialMediaDetailsProps {
  formData: {
    pageName: string;
    pageUrl: string;
    followers: string;
    category: string;
  };
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
}

export function SocialMediaDetails({ formData, onChange }: SocialMediaDetailsProps) {
  const categories = [
    'Gaming',
    'Fashion',
    'Tech',
    'Lifestyle',
    'Food',
    'Travel',
    'Fitness',
    'Education',
    'Entertainment',
    'Other'
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Social Media Page Details</h2>
      
      <div className="space-y-4">
        <div>
          <label htmlFor="pageName" className="block text-sm font-medium text-gray-700">
            Page Name
          </label>
          <input
            type="text"
            id="pageName"
            name="pageName"
            value={formData.pageName}
            onChange={onChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label htmlFor="pageUrl" className="block text-sm font-medium text-gray-700">
            Page URL
          </label>
          <input
            type="url"
            id="pageUrl"
            name="pageUrl"
            value={formData.pageUrl}
            onChange={onChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            placeholder="https://"
            required
          />
        </div>

        <div>
          <label htmlFor="followers" className="block text-sm font-medium text-gray-700">
            Number of Followers
          </label>
          <input
            type="number"
            id="followers"
            name="followers"
            value={formData.followers}
            onChange={onChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label htmlFor="category" className="block text-sm font-medium text-gray-700">
            Content Category
          </label>
          <select
            id="category"
            name="category"
            value={formData.category}
            onChange={onChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          >
            <option value="">Select a category</option>
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}